# serverless-localstack-lambda
Serverless LocalStack Lambda

# More Details Visit

https://onexlab-io.medium.com/serverless-localstack-lambda-53fd8d46983
